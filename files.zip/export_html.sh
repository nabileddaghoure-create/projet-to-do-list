#!/bin/bash
# ============================================================
#  export_html.sh — Exporter tasks.txt vers un rapport HTML
#  Usage : ./export_html.sh [fichier_source] [fichier_sortie]
# ============================================================

TASKS_FILE="${1:-tasks.txt}"
OUTPUT="${2:-rapport_todo.html}"
DATE=$(date '+%d/%m/%Y %H:%M')

# Vérifications
if [ ! -f "$TASKS_FILE" ]; then
    echo "Erreur : fichier '$TASKS_FILE' introuvable."
    exit 1
fi

TOTAL=$(wc -l < "$TASKS_FILE")
DONE=$(grep -c "|TERMINÉE|" "$TASKS_FILE" 2>/dev/null || echo 0)
PENDING=$((TOTAL - DONE))

# ── Générer les lignes du tableau ──────────────────────
generate_rows() {
    while IFS='|' read -r id title desc status priority deadline; do
        [ -z "$id" ] && continue

        # Classe CSS selon statut
        row_class=""
        [ "$status" = "TERMINÉE" ] && row_class="done"

        # Classe priorité
        case "$priority" in
            HAUTE)   prio_class="haute"   ;;
            MOYENNE) prio_class="moyenne" ;;
            *)        prio_class="basse"   ;;
        esac

        # Détection échéance dépassée
        today=$(date '+%Y-%m-%d')
        deadline_flag=""
        if [[ "$deadline" != "aucune" && "$deadline" < "$today" ]] && [ "$status" != "TERMINÉE" ]; then
            deadline_flag=" ⚠"
            deadline_class="overdue"
        else
            deadline_class=""
        fi

        echo "      <tr class=\"${row_class}\">"
        echo "        <td>#${id}</td>"
        echo "        <td>${title}</td>"
        echo "        <td>${desc}</td>"
        echo "        <td class=\"status\">${status}</td>"
        echo "        <td class=\"prio-${prio_class}\">${priority}</td>"
        echo "        <td class=\"${deadline_class}\">${deadline}${deadline_flag}</td>"
        echo "      </tr>"
    done < "$TASKS_FILE"
}

# ── Écrire le fichier HTML ─────────────────────────────
cat > "$OUTPUT" << HTMLEOF
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rapport TO DO List — ${DATE}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Courier New', monospace;
      background: #0f0f0f;
      color: #f0f0f0;
      padding: 2.5rem;
      min-height: 100vh;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      margin-bottom: 2.5rem;
      padding-bottom: 1.5rem;
      border-bottom: 1px solid #2e2e2e;
    }

    h1 {
      font-size: 3rem;
      font-weight: 900;
      letter-spacing: -2px;
      color: #f0f0f0;
    }

    h1 span { color: #c8f135; }

    .meta { color: #555; font-size: 0.8rem; text-align: right; line-height: 1.8; }

    .stats {
      display: flex;
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .stat {
      background: #1a1a1a;
      border: 1px solid #2e2e2e;
      border-radius: 8px;
      padding: 1rem 1.5rem;
      text-align: center;
    }

    .stat-num { font-size: 2rem; font-weight: 700; display: block; }
    .stat-lbl { font-size: 0.7rem; color: #555; text-transform: uppercase; letter-spacing: 2px; }

    .stat-num.accent  { color: #c8f135; }
    .stat-num.green   { color: #4ade80; }
    .stat-num.pending { color: #fbbf24; }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.82rem;
    }

    thead tr {
      background: #1a1a1a;
    }

    th {
      text-align: left;
      padding: 0.8rem 1rem;
      font-size: 0.65rem;
      letter-spacing: 3px;
      text-transform: uppercase;
      color: #c8f135;
      font-weight: 500;
    }

    td {
      padding: 0.75rem 1rem;
      border-bottom: 1px solid #1e1e1e;
      vertical-align: middle;
    }

    tr:hover td { background: #161616; }

    tr.done td {
      opacity: 0.35;
      text-decoration: line-through;
    }

    .prio-haute   { color: #f87171; }
    .prio-moyenne { color: #fbbf24; }
    .prio-basse   { color: #4ade80; }

    .status { color: #888; font-size: 0.75rem; }
    tr:not(.done) .status { color: #fbbf24; }
    tr.done .status { color: #4ade80; }

    .overdue { color: #f87171; }

    footer {
      margin-top: 2.5rem;
      padding-top: 1rem;
      border-top: 1px solid #2e2e2e;
      font-size: 0.7rem;
      color: #333;
      text-align: center;
    }
  </style>
</head>
<body>

<header>
  <h1>TO<span>DO</span><br>LIST</h1>
  <div class="meta">
    Généré le : ${DATE}<br>
    Source    : ${TASKS_FILE}
  </div>
</header>

<div class="stats">
  <div class="stat">
    <span class="stat-num accent">${TOTAL}</span>
    <span class="stat-lbl">Total</span>
  </div>
  <div class="stat">
    <span class="stat-num green">${DONE}</span>
    <span class="stat-lbl">Terminées</span>
  </div>
  <div class="stat">
    <span class="stat-num pending">${PENDING}</span>
    <span class="stat-lbl">En attente</span>
  </div>
</div>

<table>
  <thead>
    <tr>
      <th>ID</th>
      <th>Titre</th>
      <th>Description</th>
      <th>Statut</th>
      <th>Priorité</th>
      <th>Échéance</th>
    </tr>
  </thead>
  <tbody>
HTMLEOF

generate_rows >> "$OUTPUT"

cat >> "$OUTPUT" << HTMLEOF
  </tbody>
</table>

<footer>
  TO DO List — Rapport exporté automatiquement le ${DATE}
</footer>

</body>
</html>
HTMLEOF

echo "Rapport généré : ${OUTPUT} (${TOTAL} tâches)"
