# Documentation — Architecture du Projet TO DO List

## 1. Présentation générale

Ce projet est un système de gestion de tâches en ligne de commande développé en
**Bash Shell**. Il permet à l'utilisateur de gérer une liste de tâches stockée de
manière persistante dans un fichier texte (`tasks.txt`).

---

## 2. Architecture du programme

```
todo_project/
├── todo.sh          # Script principal (point d'entrée unique)
├── tasks.txt        # Base de données des tâches (généré automatiquement)
├── history.log      # Journal des modifications (généré automatiquement)
├── Makefile         # Automatisation de l'installation et des tests
├── README.md        # Manuel utilisateur
└── ARCHITECTURE.md  # Ce fichier
```

---

## 3. Structure du fichier `tasks.txt`

Chaque ligne représente une tâche selon le format CSV avec séparateur `|` :

```
ID|Titre|Description|Statut|Priorité|Échéance
```

| Champ       | Type    | Valeurs possibles                  |
|-------------|---------|-------------------------------------|
| ID          | Entier  | Entier auto-incrémenté (1, 2, 3...) |
| Titre       | Chaîne  | Texte libre                         |
| Description | Chaîne  | Texte libre ou "Sans description"   |
| Statut      | Enum    | `EN_ATTENTE` ou `TERMINÉE`          |
| Priorité    | Enum    | `HAUTE`, `MOYENNE`, `BASSE`         |
| Échéance    | Date    | `AAAA-MM-JJ` ou `aucune`            |

**Exemple :**
```
1|Rendre le rapport|Section 3 à compléter|EN_ATTENTE|HAUTE|2025-06-01
2|Acheter du café|Arabica de préférence|TERMINÉE|BASSE|aucune
```

---

## 4. Fonctions implémentées

### `init_file()`
- Crée le fichier `tasks.txt` s'il n'existe pas encore.
- Appelée automatiquement au démarrage du script.

### `log_action(message)`
- Écrit une ligne horodatée dans `history.log`.
- Format : `[AAAA-MM-JJ HH:MM:SS] message`

### `next_id()`
- Lit le fichier `tasks.txt` et retourne le prochain identifiant disponible.
- Utilise `awk` pour trouver le maximum actuel puis l'incrémente.

### `add_task()`
- Demande interactivement le titre, la description, la priorité et l'échéance.
- Valide que le titre n'est pas vide.
- Génère un ID unique et écrit la ligne dans `tasks.txt`.

### `display_tasks([filtre])`
- Affiche toutes les tâches sous forme de tableau formaté avec couleurs.
- Paramètre optionnel : filtre par statut (`EN_ATTENTE`, `TERMINÉE`) ou priorité.
- Affiche le total et le nombre de tâches terminées.

### `delete_task()`
- Affiche la liste puis demande un ID.
- Demande confirmation avant suppression.
- Utilise `sed -i` pour supprimer la ligne correspondante.

### `edit_task()`
- Affiche la liste puis demande un ID.
- Propose chaque champ avec la valeur actuelle entre crochets.
- L'utilisateur laisse vide pour garder la valeur actuelle.
- Met à jour la ligne via `sed -i`.

### `filter_tasks()`
- Menu de filtrage : par statut ou par priorité.
- Délègue à `display_tasks()` avec le filtre approprié.

### `show_history()`
- Affiche les 20 dernières lignes de `history.log`.

### `mark_done(id)`
- Marque directement une tâche comme `TERMINÉE` via son ID (mode CLI).

### `show_help()`
- Affiche l'aide complète avec toutes les options disponibles.

### `main_menu()`
- Boucle interactive avec menu numéroté.
- Lance la boucle tant que l'utilisateur ne choisit pas 0 (Quitter).

---

## 5. Gestion des arguments en ligne de commande

Le script supporte deux modes d'utilisation :

| Commande                    | Action                                  |
|-----------------------------|-----------------------------------------|
| `./todo.sh`                 | Lance le menu interactif                |
| `./todo.sh --add`           | Ajoute une tâche (mode interactif)      |
| `./todo.sh --list`          | Affiche toutes les tâches               |
| `./todo.sh --delete <id>`   | Supprime la tâche avec l'ID donné       |
| `./todo.sh --done <id>`     | Marque la tâche comme terminée          |
| `./todo.sh --history`       | Affiche le journal des modifications    |
| `./todo.sh --help`          | Affiche l'aide                          |

---

## 6. Choix d'implémentation

### Pourquoi Bash Shell ?
- Aucune dépendance externe requise (présent sur tout système Unix/Linux).
- Manipulation de fichiers texte native avec `awk`, `sed`, `grep`.
- Exécution directe sans compilation.

### Pourquoi un fichier texte CSV (séparateur `|`) ?
- Simple, lisible et modifiable manuellement.
- Compatible avec des outils comme `awk`, `cut`, `grep`.
- Séparateur `|` choisi pour éviter les conflits avec des virgules dans le texte.

### Gestion des IDs
- L'ID est un entier auto-incrémenté (jamais réutilisé après suppression).
- Cela garantit l'unicité même après des suppressions.

### Couleurs dans le terminal
- Utilisation des codes ANSI escape pour améliorer la lisibilité.
- Rouge = priorité haute / erreur, Vert = succès / terminé, Jaune = en attente / avertissement.

---

## 7. Dépendances

| Outil  | Usage                                      |
|--------|--------------------------------------------|
| `bash` | Interpréteur principal (≥ 3.2)             |
| `awk`  | Calcul d'ID, extraction de colonnes        |
| `sed`  | Modification et suppression de lignes      |
| `grep` | Recherche de tâches par ID                 |
| `wc`   | Comptage du nombre de tâches               |
| `date` | Horodatage dans le journal                 |

Tous ces outils sont disponibles en standard sur Linux, macOS, et WSL (Windows).
