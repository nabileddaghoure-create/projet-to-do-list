# Manuel Utilisateur — TO DO List

## Installation

### Prérequis
- Système Linux, macOS ou WSL (Windows Subsystem for Linux)
- Bash version 3.2 ou supérieure

### Étapes d'installation

```bash
# 1. Cloner ou copier le projet
cd todo_project/

# 2. Rendre le script exécutable (via Makefile)
make

# 3. Vérifier la syntaxe (optionnel)
make check
```

**Installation globale** (accès depuis n'importe où dans le terminal) :
```bash
make install-global
# Puis vous pouvez utiliser simplement : todo
```

---

## Utilisation

### Mode interactif (recommandé)

Lancez le script sans argument pour accéder au menu :

```bash
./todo.sh
```

Vous verrez un menu numéroté :

```
╔══════════════════════════════╗
║     TO DO LIST — MENU        ║
╚══════════════════════════════╝
  1) Ajouter une tâche
  2) Afficher toutes les tâches
  3) Supprimer une tâche
  4) Modifier une tâche
  5) Filtrer les tâches
  6) Historique des modifications
  7) Aide
  0) Quitter
```

---

### Mode ligne de commande (avancé)

Vous pouvez aussi utiliser le script directement avec des options :

#### Afficher toutes les tâches
```bash
./todo.sh --list
```

#### Ajouter une tâche
```bash
./todo.sh --add
# Le script vous guidera étape par étape
```

#### Supprimer une tâche
```bash
./todo.sh --delete 3
# Supprime la tâche avec l'ID 3
```

#### Marquer une tâche comme terminée
```bash
./todo.sh --done 2
# Marque la tâche #2 comme TERMINÉE
```

#### Voir l'historique des actions
```bash
./todo.sh --history
```

#### Afficher l'aide
```bash
./todo.sh --help
```

---

## Fonctionnalités détaillées

### 1. Ajouter une tâche
Lors de l'ajout, le système vous demande :
- **Titre** *(obligatoire)* : nom court de la tâche
- **Description** *(optionnelle)* : détails supplémentaires
- **Priorité** : Haute / Moyenne / Basse
- **Échéance** : date au format `AAAA-MM-JJ` ou vide

### 2. Afficher les tâches
Le tableau affiché utilise des **couleurs** pour faciliter la lecture :
- 🔴 Rouge : priorité HAUTE
- 🟡 Jaune : priorité MOYENNE
- 🟢 Vert  : tâche TERMINÉE

### 3. Supprimer une tâche
La suppression demande une **confirmation** avant d'effacer définitivement.

### 4. Modifier une tâche
Chaque champ est modifiable individuellement. Appuyez sur **Entrée** sans rien
écrire pour garder la valeur actuelle.

### 5. Filtrer les tâches
Vous pouvez filtrer par :
- Statut : EN_ATTENTE ou TERMINÉE
- Priorité : HAUTE, MOYENNE ou BASSE

### 6. Historique
Toutes les actions (ajout, modification, suppression) sont journalisées
automatiquement dans `history.log` avec horodatage.

---

## Structure des fichiers

```
todo_project/
├── todo.sh          ← Script principal à exécuter
├── tasks.txt        ← Vos tâches (créé automatiquement)
├── history.log      ← Journal des actions (créé automatiquement)
├── Makefile         ← Pour installation et tests
├── ARCHITECTURE.md  ← Documentation technique
└── README.md        ← Ce manuel
```

---

## Dépannage

| Problème                       | Solution                                      |
|-------------------------------|-----------------------------------------------|
| `Permission denied`           | Exécuter `chmod +x todo.sh` ou `make`         |
| `bash: todo.sh: not found`    | Vérifier que vous êtes dans le bon dossier    |
| Tâche non trouvée après ajout | Vérifier que `tasks.txt` n'est pas en lecture seule |
| Caractères `|` dans un titre  | Éviter le caractère `|` dans les titres       |

---

## Nettoyage

Pour remettre le projet à zéro (supprimer toutes les tâches et l'historique) :

```bash
make clean
```
