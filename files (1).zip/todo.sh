#!/bin/bash
# ============================================================
#  TO DO LIST - Système de gestion de tâches
#  Auteur  : Groupe ...
#  Version : 1.0
# ============================================================

TASKS_FILE="tasks.txt"
LOG_FILE="history.log"

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

# ─────────────────────────────────────────────
# Initialisation du fichier de tâches
# ─────────────────────────────────────────────
init_file() {
    if [ ! -f "$TASKS_FILE" ]; then
        touch "$TASKS_FILE"
        echo "Fichier '$TASKS_FILE' créé."
    fi
}

# ─────────────────────────────────────────────
# Journalisation des actions
# ─────────────────────────────────────────────
log_action() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# ─────────────────────────────────────────────
# Générer le prochain ID disponible
# ─────────────────────────────────────────────
next_id() {
    if [ ! -s "$TASKS_FILE" ]; then
        echo 1
    else
        awk -F'|' 'BEGIN{max=0} {if($1>max) max=$1} END{print max+1}' "$TASKS_FILE"
    fi
}

# ─────────────────────────────────────────────
# AJOUTER une tâche
# Format ligne : ID|Titre|Description|Statut|Priorité|Échéance
# ─────────────────────────────────────────────
add_task() {
    echo -e "\n${BOLD}${CYAN}=== Ajout d'une nouvelle tâche ===${RESET}"
    
    read -p "  Titre       : " title
    if [ -z "$title" ]; then
        echo -e "${RED}Erreur : le titre est obligatoire.${RESET}"
        return 1
    fi

    read -p "  Description : " desc
    desc="${desc:-Sans description}"

    echo -e "  Priorité    : [1] Haute  [2] Moyenne  [3] Basse"
    read -p "  Choix       : " prio_choice
    case "$prio_choice" in
        1) priority="HAUTE" ;;
        2) priority="MOYENNE" ;;
        *) priority="BASSE" ;;
    esac

    read -p "  Échéance (AAAA-MM-JJ, laisser vide pour aucune) : " deadline
    deadline="${deadline:-aucune}"

    id=$(next_id)
    echo "${id}|${title}|${desc}|EN_ATTENTE|${priority}|${deadline}" >> "$TASKS_FILE"
    log_action "AJOUT tâche #${id} : '${title}' [${priority}]"

    echo -e "\n${GREEN}✔ Tâche #${id} '${title}' ajoutée avec succès.${RESET}\n"
}

# ─────────────────────────────────────────────
# AFFICHER toutes les tâches
# ─────────────────────────────────────────────
display_tasks() {
    local filter="$1"  # optionnel : EN_ATTENTE | TERMINÉE | priorité

    echo -e "\n${BOLD}${BLUE}╔══════════════════════════════════════════════════════════════════╗${RESET}"
    echo -e "${BOLD}${BLUE}║              LISTE DES TÂCHES                                    ║${RESET}"
    echo -e "${BOLD}${BLUE}╚══════════════════════════════════════════════════════════════════╝${RESET}"

    if [ ! -s "$TASKS_FILE" ]; then
        echo -e "  ${YELLOW}Aucune tâche pour le moment.${RESET}\n"
        return
    fi

    printf "  ${BOLD}%-4s %-22s %-12s %-10s %-12s %-12s${RESET}\n" \
        "ID" "Titre" "Statut" "Priorité" "Échéance" "Description"
    echo -e "  ──────────────────────────────────────────────────────────────────"

    while IFS='|' read -r id title desc status priority deadline; do
        # Filtrage
        if [ -n "$filter" ]; then
            if [[ "$filter" == "EN_ATTENTE" || "$filter" == "TERMINÉE" ]]; then
                [[ "$status" != "$filter" ]] && continue
            elif [[ "$filter" == "HAUTE" || "$filter" == "MOYENNE" || "$filter" == "BASSE" ]]; then
                [[ "$priority" != "$filter" ]] && continue
            fi
        fi

        # Couleur selon statut
        if [ "$status" == "TERMINÉE" ]; then
            color=$GREEN
        elif [ "$priority" == "HAUTE" ]; then
            color=$RED
        elif [ "$priority" == "MOYENNE" ]; then
            color=$YELLOW
        else
            color=$RESET
        fi

        printf "  ${color}%-4s %-22s %-12s %-10s %-12s %-12s${RESET}\n" \
            "#${id}" "${title:0:20}" "$status" "$priority" "$deadline" "${desc:0:20}"
    done < "$TASKS_FILE"

    echo -e "  ──────────────────────────────────────────────────────────────────"
    total=$(wc -l < "$TASKS_FILE")
    done_count=$(grep -c "|TERMINÉE|" "$TASKS_FILE" 2>/dev/null || echo 0)
    echo -e "  ${BOLD}Total : ${total} tâche(s) | Terminées : ${done_count}${RESET}\n"
}

# ─────────────────────────────────────────────
# SUPPRIMER une tâche
# ─────────────────────────────────────────────
delete_task() {
    display_tasks
    read -p "  Entrez l'ID de la tâche à supprimer : " id

    if ! grep -q "^${id}|" "$TASKS_FILE"; then
        echo -e "${RED}Erreur : tâche #${id} introuvable.${RESET}\n"
        return 1
    fi

    title=$(grep "^${id}|" "$TASKS_FILE" | cut -d'|' -f2)
    read -p "  Confirmer la suppression de '${title}' ? (o/n) : " confirm
    if [[ "$confirm" =~ ^[oO]$ ]]; then
        sed -i "/^${id}|/d" "$TASKS_FILE"
        log_action "SUPPRESSION tâche #${id} : '${title}'"
        echo -e "${GREEN}✔ Tâche #${id} supprimée.${RESET}\n"
    else
        echo -e "${YELLOW}Suppression annulée.${RESET}\n"
    fi
}

# ─────────────────────────────────────────────
# MODIFIER une tâche
# ─────────────────────────────────────────────
edit_task() {
    display_tasks
    read -p "  Entrez l'ID de la tâche à modifier : " id

    if ! grep -q "^${id}|" "$TASKS_FILE"; then
        echo -e "${RED}Erreur : tâche #${id} introuvable.${RESET}\n"
        return 1
    fi

    IFS='|' read -r _ old_title old_desc old_status old_priority old_deadline \
        <<< "$(grep "^${id}|" "$TASKS_FILE")"

    echo -e "\n${CYAN}Laissez vide pour garder la valeur actuelle.${RESET}"

    read -p "  Nouveau titre       [${old_title}] : " title
    title="${title:-$old_title}"

    read -p "  Nouvelle description [${old_desc}] : " desc
    desc="${desc:-$old_desc}"

    echo -e "  Statut : [1] EN_ATTENTE  [2] TERMINÉE"
    read -p "  Choix  [${old_status}] : " status_choice
    case "$status_choice" in
        1) status="EN_ATTENTE" ;;
        2) status="TERMINÉE" ;;
        *) status="$old_status" ;;
    esac

    echo -e "  Priorité : [1] HAUTE  [2] MOYENNE  [3] BASSE"
    read -p "  Choix    [${old_priority}] : " prio_choice
    case "$prio_choice" in
        1) priority="HAUTE" ;;
        2) priority="MOYENNE" ;;
        3) priority="BASSE" ;;
        *) priority="$old_priority" ;;
    esac

    read -p "  Échéance [${old_deadline}] : " deadline
    deadline="${deadline:-$old_deadline}"

    sed -i "s/^${id}|.*/${id}|${title}|${desc}|${status}|${priority}|${deadline}/" "$TASKS_FILE"
    log_action "MODIFICATION tâche #${id} : '${title}' -> statut=${status}, priorité=${priority}"
    echo -e "${GREEN}✔ Tâche #${id} modifiée avec succès.${RESET}\n"
}

# ─────────────────────────────────────────────
# FILTRER par statut ou priorité
# ─────────────────────────────────────────────
filter_tasks() {
    echo -e "\n${BOLD}${CYAN}=== Filtrer les tâches ===${RESET}"
    echo "  [1] EN_ATTENTE"
    echo "  [2] TERMINÉE"
    echo "  [3] Priorité HAUTE"
    echo "  [4] Priorité MOYENNE"
    echo "  [5] Priorité BASSE"
    read -p "  Choix : " choice
    case "$choice" in
        1) display_tasks "EN_ATTENTE" ;;
        2) display_tasks "TERMINÉE" ;;
        3) display_tasks "HAUTE" ;;
        4) display_tasks "MOYENNE" ;;
        5) display_tasks "BASSE" ;;
        *) echo -e "${RED}Choix invalide.${RESET}" ;;
    esac
}

# ─────────────────────────────────────────────
# AFFICHER l'historique
# ─────────────────────────────────────────────
show_history() {
    echo -e "\n${BOLD}${BLUE}=== Historique des modifications ===${RESET}"
    if [ ! -f "$LOG_FILE" ] || [ ! -s "$LOG_FILE" ]; then
        echo -e "  ${YELLOW}Aucun historique disponible.${RESET}\n"
    else
        tail -20 "$LOG_FILE" | while read -r line; do
            echo -e "  ${CYAN}${line}${RESET}"
        done
        echo ""
    fi
}

# ─────────────────────────────────────────────
# AIDE
# ─────────────────────────────────────────────
show_help() {
    echo -e "\n${BOLD}${BLUE}=== Aide — TO DO List ===${RESET}"
    echo -e "  ${BOLD}Usage :${RESET} ./todo.sh [option]"
    echo ""
    echo -e "  ${BOLD}Options disponibles :${RESET}"
    echo -e "    (aucune)       Lancer le menu interactif"
    echo -e "    ${CYAN}--add${RESET}          Ajouter une tâche directement"
    echo -e "    ${CYAN}--list${RESET}         Afficher toutes les tâches"
    echo -e "    ${CYAN}--delete <id>${RESET}  Supprimer la tâche avec l'ID donné"
    echo -e "    ${CYAN}--done <id>${RESET}    Marquer une tâche comme terminée"
    echo -e "    ${CYAN}--history${RESET}      Afficher l'historique des actions"
    echo -e "    ${CYAN}--help${RESET}         Afficher cette aide"
    echo ""
    echo -e "  ${BOLD}Format du fichier tasks.txt :${RESET}"
    echo -e "    ID|Titre|Description|Statut|Priorité|Échéance"
    echo ""
    echo -e "  ${BOLD}Statuts possibles :${RESET}  EN_ATTENTE | TERMINÉE"
    echo -e "  ${BOLD}Priorités :${RESET}          HAUTE | MOYENNE | BASSE"
    echo ""
}

# ─────────────────────────────────────────────
# Marquer une tâche comme TERMINÉE (CLI rapide)
# ─────────────────────────────────────────────
mark_done() {
    local id="$1"
    if ! grep -q "^${id}|" "$TASKS_FILE"; then
        echo -e "${RED}Erreur : tâche #${id} introuvable.${RESET}"
        return 1
    fi
    sed -i "s/^${id}|\(.*\)|EN_ATTENTE|/${id}|\1|TERMINÉE|/" "$TASKS_FILE"
    title=$(grep "^${id}|" "$TASKS_FILE" | cut -d'|' -f2)
    log_action "TERMINÉE tâche #${id} : '${title}'"
    echo -e "${GREEN}✔ Tâche #${id} marquée comme terminée.${RESET}"
}

# ─────────────────────────────────────────────
# MENU PRINCIPAL
# ─────────────────────────────────────────────
main_menu() {
    while true; do
        echo -e "\n${BOLD}${BLUE}╔══════════════════════════════╗${RESET}"
        echo -e "${BOLD}${BLUE}║     TO DO LIST — MENU        ║${RESET}"
        echo -e "${BOLD}${BLUE}╚══════════════════════════════╝${RESET}"
        echo -e "  ${CYAN}1${RESET}) Ajouter une tâche"
        echo -e "  ${CYAN}2${RESET}) Afficher toutes les tâches"
        echo -e "  ${CYAN}3${RESET}) Supprimer une tâche"
        echo -e "  ${CYAN}4${RESET}) Modifier une tâche"
        echo -e "  ${CYAN}5${RESET}) Filtrer les tâches"
        echo -e "  ${CYAN}6${RESET}) Historique des modifications"
        echo -e "  ${CYAN}7${RESET}) Aide"
        echo -e "  ${CYAN}0${RESET}) Quitter"
        echo -e "${BOLD}${BLUE}────────────────────────────────${RESET}"
        read -p "  Votre choix : " choice

        case "$choice" in
            1) add_task ;;
            2) display_tasks ;;
            3) delete_task ;;
            4) edit_task ;;
            5) filter_tasks ;;
            6) show_history ;;
            7) show_help ;;
            0) echo -e "\n${GREEN}Au revoir !${RESET}\n"; exit 0 ;;
            *) echo -e "${RED}Choix invalide. Réessayez.${RESET}" ;;
        esac
    done
}

# ─────────────────────────────────────────────
# POINT D'ENTRÉE — gestion des arguments CLI
# ─────────────────────────────────────────────
init_file

case "$1" in
    --add)     add_task ;;
    --list)    display_tasks ;;
    --delete)  
        if [ -z "$2" ]; then echo -e "${RED}Usage : ./todo.sh --delete <id>${RESET}"; exit 1; fi
        # Suppression directe sans menu interactif
        id="$2"
        if ! grep -q "^${id}|" "$TASKS_FILE"; then
            echo -e "${RED}Erreur : tâche #${id} introuvable.${RESET}"; exit 1
        fi
        title=$(grep "^${id}|" "$TASKS_FILE" | cut -d'|' -f2)
        sed -i "/^${id}|/d" "$TASKS_FILE"
        log_action "SUPPRESSION tâche #${id} : '${title}'"
        echo -e "${GREEN}✔ Tâche #${id} '${title}' supprimée.${RESET}"
        ;;
    --done)    
        if [ -z "$2" ]; then echo -e "${RED}Usage : ./todo.sh --done <id>${RESET}"; exit 1; fi
        mark_done "$2" ;;
    --history) show_history ;;
    --help)    show_help ;;
    "")        main_menu ;;
    *)         echo -e "${RED}Option inconnue. Utilisez --help.${RESET}"; exit 1 ;;
esac
